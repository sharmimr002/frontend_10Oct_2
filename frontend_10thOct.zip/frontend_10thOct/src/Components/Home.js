import React from 'react';
import Layout from './Layout';
import { useNavigate } from 'react-router';

const Home=()=>{
const navigate = useNavigate();
    const handleHomeLinkClick=()=>{
        navigate('/login')
    }
    return(
<div className='bgstyle'>
        <Layout />
        <h5 className='HomeText'>Please {' '}<span onClick={handleHomeLinkClick} style={{'color': 'blue', 'textDecoration': 'none', 'cursor':'pointer'}}>{' CLICK HERE '}</span> To Login</h5>
    </div>
    )
    
}

export default Home;

